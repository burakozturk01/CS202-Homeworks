/*
* Title : Heaps and AVL Trees
* Author : Burak Ozturk
* ID : 21901841
* Section : 1
* Assignment : 3
* Description : Driver function for rotationAnalysis function
*/

#include <iostream>
#include "analysis.h"

int main() {
    rotationAnalysis();
}