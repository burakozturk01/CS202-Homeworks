/*
* Title : Heaps and AVL Trees
* Author : Burak Ozturk
* ID : 21901841
* Section : 1
* Assignment : 3
* Description : Pointer-based AVLTree declaration
*/

class Node {
public:
    Node(int keyValue);
    ~Node();
    int key;
    Node* left;
    Node* right;
    int height;
};

int max(int a, int b);

int getHeight(Node* node);

class AVLTree {
public:
    AVLTree();
    ~AVLTree();
    void insert(int value); //inserts an element into the tree
    int getNumberOfRotations(); //returns the number of rotations performed so far while constructing the tree

private:
    Node* rightRotation(Node* node);
    Node* leftRotation(Node* node);

    int heightDifference(Node* node);

    Node* insert(int value, Node* node);

    Node* root;
    int rotations;
};


#endif //PROJECT2_AVLTREE_H
